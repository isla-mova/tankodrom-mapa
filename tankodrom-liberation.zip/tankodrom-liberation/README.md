# Liberation of the Tankodrom

Party quiz for Tankodrom Milovice. Answer 10 questions, liberate the base zone by zone, and claim a reward code at the souvenir stand.

## Edit the content

Everything lives at the top of `app/page.jsx`:

- `QUESTIONS` - the 10 questions, options, and correct answer index (0-based)
- `REWARD_CODE` - the code word shown on the victory screen

Remember to swap "Oliver" in the Cromwell question for the tank's real name.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Deploy to Vercel

1. Push this repo to GitHub:

```bash
git remote add origin git@github.com:YOUR_USERNAME/tankodrom-liberation.git
git push -u origin main
```

2. In Vercel: **Add New Project** -> import the repo -> deploy. No configuration needed; Vercel auto-detects Next.js.

3. Generate a QR code pointing at the deployed URL and print it for the party posters.

## Roadmap ideas

- Merge the zone chips with the existing Leaflet map so real polygons flip red -> green
- Per-guest leaderboard of first-try scores
- Czech/English language toggle
