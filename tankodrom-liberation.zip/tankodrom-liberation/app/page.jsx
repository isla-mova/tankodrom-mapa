"use client";

import { useState } from "react";

// ─── EDIT YOUR QUESTIONS HERE ───────────────────────────────────────────────
// correct = index of the right option (0-based)
const QUESTIONS = [
  { q: "Which country does the T-34 tank come from?", options: ["Germany", "Soviet Union", "USA", "France"], correct: 1, tag: "T-34" },
  { q: "How many wheels does the Tatra 815 8x8 have?", options: ["6", "8", "10", "12"], correct: 1, tag: "TATRA 815" },
  { q: "Which Czech town is linked to Böhmerland motorcycles?", options: ["Mladá Boleslav", "Krásná Lípa", "Kopřivnice", "Plzeň"], correct: 1, tag: "BÖHMERLAND" },
  { q: "What is the top speed of the MiG-21?", options: ["1,200 km/h", "1,700 km/h", "~2,200 km/h", "2,800 km/h"], correct: 2, tag: "MiG-21" },
  { q: "What is a \u201CFlak\u201D?", options: ["A radar", "A German anti-aircraft gun", "A rocket launcher", "An engine type"], correct: 1, tag: "FLAK" },
  { q: "When did Warsaw Pact troops occupy Czechoslovakia?", options: ["1948", "1956", "1968", "1978"], correct: 2, tag: "1968" },
  { q: "Until what year did Soviet troops remain in Milovice?", options: ["1989", "1990", "1991", "1993"], correct: 2, tag: "MILOVICE" },
  { q: "Roughly how many litres does a T-55 burn per 100 km in terrain?", options: ["30 l", "100 l", "~300 l", "1,000 l"], correct: 2, tag: "T-55" },
  { q: "What is our Cromwell tank called?", options: ["Winston", "Oliver", "Betty", "Monty"], correct: 1, tag: "CROMWELL" }, // ← swap in the real name
  { q: "How many passengers fit on our T-55 ride?", options: ["2", "4", "6", "10"], correct: 1, tag: "T-55 RIDE" },
];
const REWARD_CODE = "SVOBODA"; // shown at the souvenir stand
// ────────────────────────────────────────────────────────────────────────────

const C = {
  canvas: "#D9D3BF",
  paper: "#E7E2D0",
  ink: "#2E3227",
  olive: "#4A5240",
  oliveDeep: "#373D30",
  occupied: "#9E3A2F",
  liberated: "#5C7C3B",
  orange: "#D96A2B",
};

const styleTag = `
@keyframes stampIn { 0% { transform: scale(2.2) rotate(-14deg); opacity: 0; } 60% { transform: scale(0.92) rotate(-8deg); opacity: 1; } 100% { transform: scale(1) rotate(-8deg); opacity: 1; } }
@keyframes shake { 0%,100% { transform: translateX(0); } 25% { transform: translateX(-6px); } 75% { transform: translateX(6px); } }
@keyframes flipGreen { 0% { background: ${C.occupied}; transform: scale(1); } 50% { transform: scale(1.35); } 100% { background: ${C.liberated}; transform: scale(1); } }
@media (prefers-reduced-motion: reduce) { * { animation-duration: 0.01ms !important; } }
`;

function Chip({ state, label }) {
  return (
    <div
      style={{
        flex: 1,
        height: 26,
        borderRadius: 3,
        background: state === "free" ? C.liberated : state === "active" ? C.orange : C.occupied,
        animation: state === "free" ? "flipGreen 0.5s ease" : "none",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: C.paper,
        fontFamily: "'Barlow', sans-serif",
        fontWeight: 700,
        fontSize: 10,
        letterSpacing: 0.5,
        border: `1px solid ${C.oliveDeep}`,
      }}
      title={label}
    >
      {state === "free" ? "✓" : state === "active" ? "▸" : "✕"}
    </div>
  );
}

export default function TankodromLiberation() {
  const [idx, setIdx] = useState(0);
  const [picked, setPicked] = useState(null);
  const [solved, setSolved] = useState(Array(QUESTIONS.length).fill(false));
  const [firstTry, setFirstTry] = useState(Array(QUESTIONS.length).fill(true));
  const [done, setDone] = useState(false);
  const [wrongFlash, setWrongFlash] = useState(false);

  const q = QUESTIONS[idx];
  const liberatedCount = solved.filter(Boolean).length;

  const pick = (i) => {
    if (picked === q.correct) return;
    setPicked(i);
    if (i === q.correct) {
      const s = [...solved];
      s[idx] = true;
      setSolved(s);
    } else {
      const f = [...firstTry];
      f[idx] = false;
      setFirstTry(f);
      setWrongFlash(true);
      setTimeout(() => setWrongFlash(false), 450);
    }
  };

  const next = () => {
    setPicked(null);
    if (idx + 1 < QUESTIONS.length) setIdx(idx + 1);
    else setDone(true);
  };

  const restart = () => {
    setIdx(0);
    setPicked(null);
    setSolved(Array(QUESTIONS.length).fill(false));
    setFirstTry(Array(QUESTIONS.length).fill(true));
    setDone(false);
  };

  const firstTryScore = firstTry.filter(Boolean).length;

  return (
    <div
      style={{
        minHeight: "100vh",
        background: `repeating-linear-gradient(0deg, ${C.canvas}, ${C.canvas} 3px, #D4CEBA 3px, #D4CEBA 4px)`,
        display: "flex",
        justifyContent: "center",
        padding: "16px 12px 40px",
        fontFamily: "'Barlow', sans-serif",
        color: C.ink,
      }}
    >
      <style>{styleTag}</style>
      <div style={{ width: "100%", maxWidth: 440 }}>
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 14 }}>
          <div style={{ fontFamily: "'Saira Stencil One', cursive", fontSize: 13, letterSpacing: 4, color: C.olive }}>
            TANKODROM MILOVICE PRESENTS
          </div>
          <h1 style={{ fontFamily: "'Saira Stencil One', cursive", fontSize: 32, margin: "2px 0 0", color: C.oliveDeep, lineHeight: 1.05 }}>
            LIBERATION OF THE TANKODROM
          </h1>
          <div style={{ fontSize: 13, marginTop: 6, color: C.olive, fontWeight: 600 }}>
            Answer all 10 correctly, liberate the base, claim your reward at the souvenir stand.
          </div>
        </div>

        {/* Liberation strip */}
        <div style={{ display: "flex", gap: 4, marginBottom: 6 }}>
          {QUESTIONS.map((qq, i) => (
            <Chip key={i} label={qq.tag} state={solved[i] ? "free" : i === idx && !done ? "active" : "occupied"} />
          ))}
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, fontWeight: 700, letterSpacing: 1, marginBottom: 16, color: C.olive }}>
          <span>ZONES LIBERATED</span>
          <span>{liberatedCount} / {QUESTIONS.length}</span>
        </div>

        {!done ? (
          <div
            style={{
              background: C.paper,
              border: `2px solid ${C.oliveDeep}`,
              borderRadius: 6,
              padding: "18px 16px 20px",
              boxShadow: "4px 4px 0 rgba(46,50,39,0.25)",
              position: "relative",
              animation: wrongFlash ? "shake 0.35s ease" : "none",
            }}
          >
            <div style={{ fontFamily: "'Saira Stencil One', cursive", fontSize: 12, letterSpacing: 3, color: C.orange, marginBottom: 6 }}>
              SECTOR {String(idx + 1).padStart(2, "0")} — {q.tag}
            </div>
            <div style={{ fontSize: 19, fontWeight: 700, lineHeight: 1.3, marginBottom: 16 }}>{q.q}</div>

            <div style={{ display: "grid", gap: 8 }}>
              {q.options.map((opt, i) => {
                const isCorrectPick = picked === q.correct && i === q.correct;
                const isWrongPick = picked === i && i !== q.correct;
                return (
                  <button
                    key={i}
                    onClick={() => pick(i)}
                    style={{
                      padding: "13px 14px",
                      fontSize: 16,
                      fontWeight: 600,
                      fontFamily: "'Barlow', sans-serif",
                      textAlign: "left",
                      borderRadius: 4,
                      cursor: "pointer",
                      border: `2px solid ${isCorrectPick ? C.liberated : isWrongPick ? C.occupied : C.oliveDeep}`,
                      background: isCorrectPick ? "#DCE8CB" : isWrongPick ? "#EBD2CD" : "#F2EEDF",
                      color: C.ink,
                      transition: "background 0.15s, border-color 0.15s",
                    }}
                  >
                    {opt}
                    {isWrongPick && <span style={{ float: "right", color: C.occupied, fontWeight: 700 }}>try again</span>}
                  </button>
                );
              })}
            </div>

            {picked === q.correct && (
              <div
                style={{
                  position: "absolute",
                  top: 8,
                  right: 10,
                  fontFamily: "'Saira Stencil One', cursive",
                  fontSize: 22,
                  color: C.liberated,
                  border: `3px solid ${C.liberated}`,
                  borderRadius: 4,
                  padding: "2px 10px",
                  transform: "rotate(-8deg)",
                  animation: "stampIn 0.35s ease forwards",
                  background: "rgba(231,226,208,0.9)",
                }}
              >
                LIBERATED
              </div>
            )}

            {picked === q.correct && (
              <button
                onClick={next}
                style={{
                  marginTop: 16,
                  width: "100%",
                  padding: "14px",
                  fontFamily: "'Saira Stencil One', cursive",
                  fontSize: 17,
                  letterSpacing: 2,
                  background: C.olive,
                  color: C.paper,
                  border: `2px solid ${C.oliveDeep}`,
                  borderRadius: 4,
                  cursor: "pointer",
                }}
              >
                {idx + 1 < QUESTIONS.length ? "ADVANCE TO NEXT SECTOR ▸" : "COMPLETE THE LIBERATION ▸"}
              </button>
            )}
          </div>
        ) : (
          <div
            style={{
              background: C.paper,
              border: `2px solid ${C.oliveDeep}`,
              borderRadius: 6,
              padding: "26px 18px",
              textAlign: "center",
              boxShadow: "4px 4px 0 rgba(46,50,39,0.25)",
            }}
          >
            <div style={{ fontFamily: "'Saira Stencil One', cursive", fontSize: 30, color: C.liberated }}>
              TANKODROM LIBERATED
            </div>
            <div style={{ fontSize: 14, margin: "8px 0 18px", fontWeight: 600 }}>
              First-try hits: {firstTryScore} / {QUESTIONS.length}
            </div>
            <div style={{ fontSize: 13, letterSpacing: 1, fontWeight: 700, color: C.olive }}>SHOW THIS CODE AT THE SOUVENIR STAND</div>
            <div
              style={{
                fontFamily: "'Saira Stencil One', cursive",
                fontSize: 40,
                letterSpacing: 6,
                color: C.orange,
                border: `3px dashed ${C.orange}`,
                borderRadius: 6,
                padding: "8px 0",
                margin: "10px 0 20px",
                transform: "rotate(-2deg)",
              }}
            >
              {REWARD_CODE}
            </div>
            <button
              onClick={restart}
              style={{
                padding: "10px 22px",
                fontFamily: "'Barlow', sans-serif",
                fontWeight: 700,
                fontSize: 14,
                background: "transparent",
                color: C.olive,
                border: `2px solid ${C.olive}`,
                borderRadius: 4,
                cursor: "pointer",
              }}
            >
              Play again
            </button>
          </div>
        )}

        <div style={{ textAlign: "center", marginTop: 22, fontFamily: "'Saira Stencil One', cursive", fontSize: 13, letterSpacing: 3, color: C.olive }}>
          TANKODROM ★ MILOVICE
        </div>
      </div>
    </div>
  );
}
