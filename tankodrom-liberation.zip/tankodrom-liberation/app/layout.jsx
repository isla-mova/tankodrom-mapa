export const metadata = {
  title: "Liberation of the Tankodrom",
  description:
    "Answer 10 questions, liberate the Tankodrom, and claim your reward at the souvenir stand. Tankodrom Milovice party quiz.",
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#4A5240",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Saira+Stencil+One&family=Barlow:wght@400;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body style={{ margin: 0 }}>{children}</body>
    </html>
  );
}
